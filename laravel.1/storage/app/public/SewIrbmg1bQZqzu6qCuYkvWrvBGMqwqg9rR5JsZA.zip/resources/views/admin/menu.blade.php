<li class="nav-item"><a class="nav-link" href="{{ route('Home') }}">Главная</a></li>
<li class="nav-item"><a class="nav-link" href="{{ route('admin.create') }}">Добавить новость</a></li>
<li class="nav-item"><a class="nav-link" href="{{ route('admin.downloadImage') }}">Скачать изображение</a></li>
<li class="nav-item"><a class="nav-link" href="{{ route('admin.json') }}">Скачать JSON</a></li>

