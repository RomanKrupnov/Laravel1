<li class="nav-item <?php echo e(request()->routeIs('Home')?'active':''); ?>"><a class="nav-link" href="<?php echo e(route('Home')); ?>">Главная</a></li>

<li class="nav-item <?php echo e(request()->routeIs('news.index')?'active':''); ?>"><a class="nav-link"  href="<?php echo e(route('news.index')); ?>">Новости</a>
</li>

<li class="nav-item <?php echo e(request()->routeIs('news.category.index')?'active':''); ?>"><a class="nav-link" href="<?php echo e(route('news.category.index')); ?>">Категории</a>
</li>

<li class="nav-item <?php echo e(request()->routeIs('admin.index')?'active':''); ?>"><a class="nav-link"  href="<?php echo e(route('admin.index')); ?>">Админка</a>
</li>

<li class="nav-item <?php echo e(request()->routeIs('vue')?'active':''); ?>"><a class="nav-link" href="<?php echo e(route('vue')); ?>">Vue
        Page</a></li>
<?php /**PATH C:\OSPanel\domains\laravel.local\resources\views/menu.blade.php ENDPATH**/ ?>