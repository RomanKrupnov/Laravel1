<?php $__env->startSection('title', 'Добавить новость'); ?>


<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">

                        <form enctype="multipart/form-data" method="POST"
                              action="<?php if(!$news->id): ?><?php echo e(route('admin.create')); ?><?php else: ?><?php echo e(route('admin.update', $news)); ?><?php endif; ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="newsTitle">Название новости</label>
                                <?php if($errors->has('title')): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php $__currentLoopData = $errors->get('title'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <input name="title" type="text" class="form-control" id="newsTitle"
                                       value="<?php echo e($news->title ?? old('title')); ?>">
                            </div>


                            <div class="form-group">
                                <label for="newsCategory">Категория новости</label>
                                <?php if($errors->has('category_id')): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php $__currentLoopData = $errors->get('category_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <select name="category_id" class="form-control" id="newsCategory">
                                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option <?php if($item['id'] == old('category')): ?> selected
                                                <?php endif; ?> value="<?php echo e($item['id']); ?>"><?php echo e($item['category']); ?></option>
                                        <option value="55">не верная категория</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <h2>Нет категории</h2>
                                    <?php endif; ?>

                                </select>

                            </div>

                            <div class="form-group">
                                <label for="newsText">Текст новости</label>
                                <?php if($errors->has('text')): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php $__currentLoopData = $errors->get('text'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <textarea name="text" class="form-control" rows="5"
                                          id="newsText"><?php echo e($news->text ?? old('text')); ?></textarea>
                            </div>

                            <div class="form-group">
                                <?php if($errors->has('image')): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php $__currentLoopData = $errors->get('image'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                                <input type="file" name="image">
                            </div>
                            <?php
                            //TODO Поправить вывод категории из old
                            ?>
                            <div class="form-check">
                                <input <?php if($news->isPrivate == 1 || old('isPrivate') == 1): ?> checked
                                       <?php endif; ?> name="isPrivate" class="form-check-input" type="checkbox" value="1"
                                       id="newsPrivate">
                                <label class="form-check-label" for="newsPrivate">
                                    Новость private?
                                </label>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="form-control">
                                    <?php if($news->id): ?><?php echo e(__('Изменить')); ?><?php else: ?><?php echo e(__('Добавить')); ?><?php endif; ?>
                                </button>

                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\laravel.local\resources\views/admin/create.blade.php ENDPATH**/ ?>