<?php $__env->startSection('title', 'Тест1'); ?>


<?php $__env->startSection('menu'); ?>
    <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-body">

                        <form method="POST" action="<?php echo e(route('admin.create')); ?>">
                            <?php echo csrf_field(); ?>


                            <div class="form-group">
                                <label for="newsTitle">Название новости</label>
                                <input name="title" type="text" class="form-control" id="newsTitle" value="<?php echo e(old('title')); ?>">
                            </div>


                            <div class="form-group">
                                <label for="newsCategory">Категория новости</label>
                                <select name="category" class="form-control" id="newsCategory">
                                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option <?php if($item['id'] == old('category')): ?> selected <?php endif; ?> value="<?php echo e($item['id']); ?>"><?php echo e($item['category']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <h2>Нет категории</h2>
                                    <?php endif; ?>

                                </select>

                            </div>

                            <div class="form-group">
                                <label for="newsText">Текст новости</label>
                                <textarea name="text" class="form-control" rows="5" id="newsText"><?php echo e(old('text')); ?></textarea>
                            </div>

                            <div class="form-check">
                                <input <?php if(old('isPrivate') == 1): ?> checked <?php endif; ?> name="isPrivate" class="form-check-input" type="checkbox" value="1"
                                       id="newsPrivate">
                                <label class="form-check-label" for="newsPrivate">
                                    Новость private?
                                </label>
                            </div>

                            <div class="form-group">
                                <input type="submit" class="btn btn-outline-primary" value="Добавить новость"
                                       id="addNews">
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\laravel\resources\views/admin/create.blade.php ENDPATH**/ ?>